ADHI FURNITURE WEBSITE

Files:
- index.html: the complete responsive website.

Preview:
1. Open index.html in Chrome or another web browser.
2. WhatsApp is set to +91 89782 85500. The phone contact is set to +91 70933 42177.
3. Replace "Add your factory address" with your factory address.

Notes:
- The website uses online image URLs, so an internet connection is needed to show the photos.
- The enquiry form opens WhatsApp after you add your number.
- To publish online, upload index.html to a static website host or your domain hosting.
